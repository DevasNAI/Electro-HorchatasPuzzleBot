classdef APP_POLLOS_exported < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                 matlab.ui.Figure
        GridLayout               matlab.ui.container.GridLayout
        LeftPanel                matlab.ui.container.Panel
        Browsevideomp4Button     matlab.ui.control.Button
        TextArea                 matlab.ui.control.TextArea
        Label                    matlab.ui.control.Label
        Hyperlink                matlab.ui.control.Hyperlink
        Image                    matlab.ui.control.Image
        BrowsefilenamecsvButton  matlab.ui.control.Button
        RightPanel               matlab.ui.container.Panel
        Image2                   matlab.ui.control.Image
        UIAxes3                  matlab.ui.control.UIAxes
        UIAxes2                  matlab.ui.control.UIAxes
        UIAxes                   matlab.ui.control.UIAxes
    end

    % Properties that correspond to apps with auto-reflow
    properties (Access = private)
        onePanelWidth = 576;
    end

    % Callbacks that handle component events
    methods (Access = private)

        % Button pushed function: BrowsefilenamecsvButton
        function BrowsefilenamecsvButtonPushed(app, event)
            tipos={'*.csv'};
            [filename,path]=uigetfile(tipos);
            t=fullfile(path,filename);
            Array=readtable(t);
            col1 = Array{:, 1};
            col2 = Array{:, 2};
          
            plot(app.UIAxes,col1,col2)
            v = 0.10*(ones(2083, 1));
        
            plot3(app.UIAxes2,col1, col2,v)
        end

        % Button pushed function: Browsevideomp4Button
        function Browsevideomp4ButtonPushed(app, event)
            tipos={'*mp4'};
            [filename,path]=uigetfile(tipos);
            video= fullfile(path,filename);
            vid=VideoReader(video); 
            while (hasFrame(vid))
                frame=readFrame(vid);
                imshow(frame,'Parent',app.UIAxes3);
                pause(2/vid.FrameRate);
            end
        end

        % Changes arrangement of the app based on UIFigure width
        function updateAppLayout(app, event)
            currentFigureWidth = app.UIFigure.Position(3);
            if(currentFigureWidth <= app.onePanelWidth)
                % Change to a 2x1 grid
                app.GridLayout.RowHeight = {477, 477};
                app.GridLayout.ColumnWidth = {'1x'};
                app.RightPanel.Layout.Row = 2;
                app.RightPanel.Layout.Column = 1;
            else
                % Change to a 1x2 grid
                app.GridLayout.RowHeight = {'1x'};
                app.GridLayout.ColumnWidth = {255, '1x'};
                app.RightPanel.Layout.Row = 1;
                app.RightPanel.Layout.Column = 2;
            end
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Get the file path for locating images
            pathToMLAPP = fileparts(mfilename('fullpath'));

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.AutoResizeChildren = 'off';
            app.UIFigure.Color = [1 0 0];
            app.UIFigure.Position = [100 100 976 477];
            app.UIFigure.Name = 'MATLAB App';
            app.UIFigure.SizeChangedFcn = createCallbackFcn(app, @updateAppLayout, true);

            % Create GridLayout
            app.GridLayout = uigridlayout(app.UIFigure);
            app.GridLayout.ColumnWidth = {255, '1x'};
            app.GridLayout.RowHeight = {'1x'};
            app.GridLayout.ColumnSpacing = 0;
            app.GridLayout.RowSpacing = 0;
            app.GridLayout.Padding = [0 0 0 0];
            app.GridLayout.Scrollable = 'on';

            % Create LeftPanel
            app.LeftPanel = uipanel(app.GridLayout);
            app.LeftPanel.ForegroundColor = [1 1 1];
            app.LeftPanel.BackgroundColor = [0.651 0.651 0.651];
            app.LeftPanel.Layout.Row = 1;
            app.LeftPanel.Layout.Column = 1;

            % Create BrowsefilenamecsvButton
            app.BrowsefilenamecsvButton = uibutton(app.LeftPanel, 'push');
            app.BrowsefilenamecsvButton.ButtonPushedFcn = createCallbackFcn(app, @BrowsefilenamecsvButtonPushed, true);
            app.BrowsefilenamecsvButton.BackgroundColor = [0.902 0.902 0.902];
            app.BrowsefilenamecsvButton.FontSize = 15;
            app.BrowsefilenamecsvButton.Position = [45 265 174 27];
            app.BrowsefilenamecsvButton.Text = 'Browse (filename.csv)';

            % Create Image
            app.Image = uiimage(app.LeftPanel);
            app.Image.Position = [6 7 243 200];
            app.Image.ImageSource = fullfile(pathToMLAPP, 'OneDrive', 'Escritorio', 'APP_POLLOS', 'pollos.png');

            % Create Hyperlink
            app.Hyperlink = uihyperlink(app.LeftPanel);
            app.Hyperlink.FontSize = 15;
            app.Hyperlink.URL = 'https://github.com/DevasNAI/Electro-HorchatasPuzzleBot/tree/main/cvModule/pollos';
            app.Hyperlink.Position = [90 296 88 22];
            app.Hyperlink.Text = 'Github Link';

            % Create Label
            app.Label = uilabel(app.LeftPanel);
            app.Label.BackgroundColor = [0.9412 0.9412 0.9412];
            app.Label.HorizontalAlignment = 'right';
            app.Label.Position = [5 446 25 22];
            app.Label.Text = '';

            % Create TextArea
            app.TextArea = uitextarea(app.LeftPanel);
            app.TextArea.BackgroundColor = [0.9412 0.9412 0.9412];
            app.TextArea.Position = [45 345 200 125];
            app.TextArea.Value = {'El proyecto consiste en la deteccion de pollitos, para conocer su desplazamiento a partir de un video. '; ''; 'En esta app se despliegan las graficas en 2D y 3D de su trayectoria. '};

            % Create Browsevideomp4Button
            app.Browsevideomp4Button = uibutton(app.LeftPanel, 'push');
            app.Browsevideomp4Button.ButtonPushedFcn = createCallbackFcn(app, @Browsevideomp4ButtonPushed, true);
            app.Browsevideomp4Button.BackgroundColor = [0.902 0.902 0.902];
            app.Browsevideomp4Button.FontSize = 15;
            app.Browsevideomp4Button.Position = [47 225 174 27];
            app.Browsevideomp4Button.Text = 'Browse (video.mp4)';

            % Create RightPanel
            app.RightPanel = uipanel(app.GridLayout);
            app.RightPanel.BackgroundColor = [1 0.4118 0.1608];
            app.RightPanel.Layout.Row = 1;
            app.RightPanel.Layout.Column = 2;

            % Create UIAxes
            app.UIAxes = uiaxes(app.RightPanel);
            title(app.UIAxes, '2D')
            xlabel(app.UIAxes, 'X')
            ylabel(app.UIAxes, 'Y')
            zlabel(app.UIAxes, 'Z')
            app.UIAxes.Position = [42 270 309 190];

            % Create UIAxes2
            app.UIAxes2 = uiaxes(app.RightPanel);
            title(app.UIAxes2, '3D')
            xlabel(app.UIAxes2, 'X')
            ylabel(app.UIAxes2, 'Y')
            zlabel(app.UIAxes2, 'Z')
            app.UIAxes2.Position = [41 11 334 209];

            % Create UIAxes3
            app.UIAxes3 = uiaxes(app.RightPanel);
            title(app.UIAxes3, 'Video')
            zlabel(app.UIAxes3, 'Z')
            app.UIAxes3.Position = [400 15 300 185];

            % Create Image2
            app.Image2 = uiimage(app.RightPanel);
            app.Image2.Position = [411 236 277 241];
            app.Image2.ImageSource = fullfile(pathToMLAPP, 'OneDrive', 'Escritorio', 'APP_POLLOS', 'pollo3d.png');

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = APP_POLLOS_exported

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end